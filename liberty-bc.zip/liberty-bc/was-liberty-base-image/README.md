# WebSphere Liberty Base Image

Base image for Liberty applications at pixiecloud NC.

## Usage
```dockerfile
FROM ghe.pixiecloud.com/was-liberty-base-image:latest
```
# Test change
