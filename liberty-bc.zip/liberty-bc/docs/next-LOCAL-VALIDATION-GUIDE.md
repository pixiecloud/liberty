# Liberty Base Image - Local Validation Guide (FINAL)

## Current Status

✅ Base image built and in ECR: `126924000548.dkr.ecr.us-east-1.amazonaws.com/liberty/liberty-base:latest`
✅ Base image uses IBM WebSphere Liberty kernel from ICR
✅ 197 features cached at `/opt/ibm/wlp/feature-cache`
✅ Tested and validated successfully - February 14, 2026

## Complete Validation Steps

### Step 1: Verify Base Image in ECR

```bash
# Check ECR has the latest image
aws ecr describe-images --repository-name liberty/liberty-base --region us-east-1

# Should show image pushed today (Feb 14, 2026) with ~525MB size
# Digest: sha256:8ca3c2ef915b226a69c2b0fc20df468c9415b31830a49e2313030143e2a7f2d5
```

### Step 2: Verify Daniel's Base Image Dockerfile

```bash
cd ~/liberty-bc/was-liberty-base-image

# CRITICAL: Verify the Dockerfile uses ECR base image
head -5 Dockerfile

# Should show:
# FROM 126924000548.dkr.ecr.us-east-1.amazonaws.com/liberty/liberty-base:latest
```

**If the Dockerfile is incorrect, restore it:**

```bash
cd ~/liberty-bc/was-liberty-base-image

cat > Dockerfile <<'EOF'
FROM 126924000548.dkr.ecr.us-east-1.amazonaws.com/liberty/liberty-base:latest

ARG APP_REMOVE_SRC_CODE=false

LABEL io.openshift.s2i.scripts-url=image:///usr/local/s2i \
    io.s2i.scripts-url=image:///usr/local/s2i \
    io.k8s.description="Platform for building and running JEE applications on IBM WebSphere Liberty Profile" \
    io.openshift.expose-services="9080:tcp,9443:https" \
    io.openshift.tags="runner,builder,liberty" \
    io.openshift.s2i.destination="/tmp"

USER root

# Copy root scripts
COPY ./root/ /

# Copy default server.env, jvm.options to /config
COPY contrib/ /config/

# Copy dependency params
COPY contrib/dependency.params /tmp

# Copy the S2I scripts
COPY ./s2i/bin/ /usr/local/s2i/

RUN chmod 777 /usr/bin/container-entrypoint && \
    chmod 777 /usr/bin/base-usage && \
    chmod 777 /usr/bin/fix-permissions && \
    chmod -R 777 /usr/local/s2i/

# Update privileges
RUN mkdir -p /config/project && \
    chown -R 1001:0 /config && \
    chmod -R g+rw /config && \
    chown -R 1001:0 /opt/ibm/wlp && \
    chmod -R g+rw /opt/ibm/wlp

USER 1001

EXPOSE 9080 9443

WORKDIR /opt/app-root/src

ENTRYPOINT ["container-entrypoint"]

CMD ["base-usage"]
EOF
```

### Step 3: Build Daniel's Base Image

```bash
cd ~/liberty-bc/was-liberty-base-image

# Build the base image (extends ECR base)
docker build -t my-liberty-base:test .

# Should complete successfully with no errors
# Should show: FROM 126924000548.dkr.ecr.us-east-1.amazonaws.com/liberty/liberty-base:latest
```

### Step 4: Create Test Application

```bash
cd ~/liberty-bc
mkdir -p app-test
cd app-test

# Create server.xml for test app
cat > server.xml <<'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<server description="Test application">
    <featureManager>
        <feature>jaxrs-2.1</feature>
        <feature>mpHealth-3.0</feature>
    </featureManager>
    
    <httpEndpoint id="defaultHttpEndpoint" host="*" httpPort="9080"/>
    <mpHealth/>
</server>
EOF

# Create Dockerfile that installs features from cache
cat > Dockerfile <<'EOF'
FROM my-liberty-base:test

USER root

# Copy server configuration
COPY server.xml /config/server.xml

# CRITICAL: Install features from cache using installUtility
RUN /opt/ibm/wlp/bin/installUtility install --acceptLicense --from=/opt/ibm/wlp/feature-cache /config/server.xml

# Set permissions
RUN chown -R 1001:0 /opt/ibm/wlp && \
    chmod -R g+rw /opt/ibm/wlp

USER 1001

CMD ["/opt/ibm/wlp/bin/server", "run", "defaultServer"]
EOF
```

### Step 5: Build and Run Test App

```bash
# Stop any existing containers on port 9080
docker stop $(docker ps -q --filter "publish=9080") 2>/dev/null || true
docker rm test-app 2>/dev/null || true

# Build test app
docker build -t test-app .

# Run test app
docker run -d -p 9080:9080 --name test-app test-app

# Wait for Liberty to start
sleep 30
```

### Step 6: Validate Success

```bash
# Check logs - should show features installed
docker logs test-app | grep "CWWKF0012I"

# Expected output:
# [AUDIT   ] CWWKF0012I: The server installed the following features: [cdi-2.0, jaxrs-2.1, jaxrsClient-2.1, jndi-1.0, json-1.0, jsonp-1.1, mpConfig-2.0, mpHealth-3.0, servlet-4.0]

# Test health endpoint
curl http://localhost:9080/health/live

# Expected output:
# {"status":"UP","checks":[]}

# Verify NO IBM repository calls
docker logs test-app | grep -i "ibm.com" || echo "✅ No IBM repository calls - features loaded from cache!"
```

### Step 7: Clean Up

```bash
docker stop test-app
docker rm test-app
```

## Complete Architecture Flow

```
┌─────────────────────────────────────────────────────────────┐
│ 1. ECR Base Image                                           │
│    126924000548...liberty-base:latest                       │
│    • Based on: icr.io/.../websphere-liberty:kernel         │
│    • Contains: 197 cached features                          │
│    • Size: ~525MB                                           │
└─────────────────────────────────────────────────────────────┘
                           ↓ FROM
┌─────────────────────────────────────────────────────────────┐
│ 2. Daniel's Base Image (my-liberty-base:test)               │
│    ~/liberty-bc/was-liberty-base-image/                    │
│    • Adds: S2I scripts, config files                        │
│    • Purpose: Standard base for all apps                    │
└─────────────────────────────────────────────────────────────┘
                           ↓ FROM
┌─────────────────────────────────────────────────────────────┐
│ 3. Application Image (test-app)                             │
│    ~/liberty-bc/app-test/                                  │
│    • Adds: server.xml, application code                     │
│    • Installs: Features from cache with installUtility     │
└─────────────────────────────────────────────────────────────┘
                           ↓ RUN
┌─────────────────────────────────────────────────────────────┐
│ 4. Running Container                                        │
│    • Features: Loaded from /opt/ibm/wlp/feature-cache     │
│    • No external calls to IBM repository ✅                 │
│    • Health endpoint: {"status":"UP"} ✅                    │
└─────────────────────────────────────────────────────────────┘
```

## Success Criteria

- [x] ECR base image accessible and correct size (~525MB)
- [x] Daniel's base image Dockerfile uses ECR base (line 1)
- [x] Daniel's base image builds successfully
- [x] Test application builds without errors
- [x] Liberty server starts successfully
- [x] Health endpoints return `{"status":"UP","checks":[]}`
- [x] Features load from local cache at `/opt/ibm/wlp/feature-cache`
- [x] No calls to IBM external repository
- [x] Server starts in < 2 seconds
- [x] All required features available and installed

## Troubleshooting

### Dockerfile Shows Wrong FROM Statement

**Problem:** `was-liberty-base-image/Dockerfile` shows `FROM my-liberty-base:test` instead of ECR image

**Cause:** Dockerfile got overwritten during testing

**Solution:** Restore the correct Dockerfile using the script in Step 2

### Features Not Found Error

**Problem:** `CWWKF0042E: A feature definition cannot be found`

**Solution:** Make sure the application Dockerfile includes:
```dockerfile
RUN /opt/ibm/wlp/bin/installUtility install --acceptLicense --from=/opt/ibm/wlp/feature-cache /config/server.xml
```

### Port 9080 Already in Use

**Problem:** `Bind for 0.0.0.0:9080 failed: port is already allocated`

**Solution:** 
```bash
docker stop $(docker ps -q --filter "publish=9080")
```

### Container Shows "base-usage" Message

**Problem:** Container runs but shows "This is the Liberty base image. To use this image, extend it with your application."

**Solution:** Application Dockerfile must include:
```dockerfile
CMD ["/opt/ibm/wlp/bin/server", "run", "defaultServer"]
```

## What This Validates

This validation proves:

1. ✅ **IBM WebSphere Liberty compatibility** - Base image uses official IBM Liberty kernel from ICR
2. ✅ **Feature caching works** - All 197 features available in `/opt/ibm/wlp/feature-cache`
3. ✅ **No external dependencies** - Zero IBM repository calls during application builds
4. ✅ **Daniel's structure compatible** - Works with existing repository architecture
5. ✅ **Production ready** - Health endpoints, proper startup, fast deployment (<2 sec)
6. ✅ **Complete chain validated** - ECR → Daniel's base → Application → Running container

## Next Steps - Monday Work PC

Once local validation passes:

1. Clone Daniel's work repository:
   ```bash
   git clone https://ghe.bcbsnc.com/bcbs-base-images/was-liberty-base-image.git
   ```

2. Make TWO changes:
   - **Dockerfile line 2**: Change to ECR base image
   - **s2i/bin/assemble lines 95, 97, 99**: Add `--from=/opt/ibm/wlp/feature-cache`

3. Create Pull Request with detailed description

4. Get approval from @daniel

5. Merge to main

6. Deploy to production

---

**Validation Status:** ✅ PASSED  
**Last Tested:** February 14, 2026, 3:37 PM EST  
**Base Image:** `126924000548.dkr.ecr.us-east-1.amazonaws.com/liberty/liberty-base:latest`  
**Liberty Version:** 26.0.0.1  
**Features Cached:** 197  
**Test Result:** Health endpoint returned `{"status":"UP","checks":[]}`  
**External Calls:** 0 (all features from cache)
