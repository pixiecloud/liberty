# Liberty Base Image - Installation Guide

## Phase 1: Download and Extract Liberty

```bash
cd ~
mkdir -p liberty-bc
cd liberty-bc

wget https://public.dhe.ibm.com/ibmdl/export/pub/software/websphere/wasdev/downloads/wlp/26.0.0.1/wlp-javaee8-26.0.0.1.zip

unzip wlp-javaee8-26.0.0.1.zip

cd wlp
```

## Phase 2: Download Features to Local Cache

```bash
./bin/installUtility download --location=./feature-cache --acceptLicense \
  beanValidation-2.0 \
  cdi-2.0 \
  jaxrs-2.1 \
  jdbc-4.2 \
  jndi-1.0 \
  jpa-2.2 \
  mpMetrics-3.0 \
  mpHealth-3.0

tar -czf liberty-feature-cache-26.0.0.1.tar.gz feature-cache/
```

## Phase 3: Upload to S3

```bash
aws s3 cp ../wlp-javaee8-26.0.0.1.zip \
  s3://opentofu-state-bucket-donot-delete2/liberty/wlp-javaee8-26.0.0.1.zip

aws s3 cp liberty-feature-cache-26.0.0.1.tar.gz \
  s3://opentofu-state-bucket-donot-delete2/liberty/liberty-feature-cache-26.0.0.1.tar.gz

aws s3 ls s3://opentofu-state-bucket-donot-delete2/liberty/
```

## Phase 4: Build Docker Image

```bash
cd ~/liberty-bc
mkdir -p docker-build
cd ~/liberty-bc/docker-build

cat > Dockerfile <<'EOF'
FROM icr.io/appcafe/websphere-liberty:kernel-java11-openj9-ubi

USER root

ARG AWS_ACCESS_KEY_ID
ARG AWS_SECRET_ACCESS_KEY
ARG AWS_DEFAULT_REGION=us-east-1

# Install AWS CLI (UBI uses yum)
RUN yum install -y curl unzip tar gzip && \
    curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "awscliv2.zip" && \
    unzip awscliv2.zip && \
    ./aws/install && \
    rm -rf aws awscliv2.zip && \
    yum clean all

ENV AWS_ACCESS_KEY_ID=$AWS_ACCESS_KEY_ID \
    AWS_SECRET_ACCESS_KEY=$AWS_SECRET_ACCESS_KEY \
    AWS_DEFAULT_REGION=$AWS_DEFAULT_REGION

# Download and extract feature cache from S3
RUN aws s3 cp s3://opentofu-state-bucket-donot-delete2/liberty/liberty-feature-cache-26.0.0.1.tar.gz /tmp/ && \
    tar -xzf /tmp/liberty-feature-cache-26.0.0.1.tar.gz -C /opt/ibm/wlp/ && \
    rm /tmp/liberty-feature-cache-26.0.0.1.tar.gz

# Unset credentials
ENV AWS_ACCESS_KEY_ID= \
    AWS_SECRET_ACCESS_KEY= \
    AWS_DEFAULT_REGION=

USER 1001

CMD ["/opt/ibm/wlp/bin/server", "run", "defaultServer"]
EOF

# Build
docker build \
  --build-arg AWS_ACCESS_KEY_ID=$(aws configure get aws_access_key_id) \
  --build-arg AWS_SECRET_ACCESS_KEY=$(aws configure get aws_secret_access_key) \
  -t liberty-with-deps:26.0.0.1 .
```

## Phase 5: Push to ECR

```bash
docker tag liberty-with-deps:26.0.0.1 \
  126924000548.dkr.ecr.us-east-1.amazonaws.com/liberty/liberty-base:26.0.0.1

docker tag liberty-with-deps:26.0.0.1 \
  126924000548.dkr.ecr.us-east-1.amazonaws.com/liberty/liberty-base:latest

aws ecr get-login-password --region us-east-1 | \
  docker login --username AWS --password-stdin \
  126924000548.dkr.ecr.us-east-1.amazonaws.com

docker push 126924000548.dkr.ecr.us-east-1.amazonaws.com/liberty/liberty-base:26.0.0.1
docker push 126924000548.dkr.ecr.us-east-1.amazonaws.com/liberty/liberty-base:latest

aws ecr describe-images --repository-name liberty/liberty-base --region us-east-1
```


## Let's check what's actually in the base image:
```sh
# Check what features are in the cache
docker run --rm 126924000548.dkr.ecr.us-east-1.amazonaws.com/liberty/liberty-base:latest \
  ls -la /opt/ibm/wlp/feature-cache/features/

# Also check if the directory exists
docker run --rm 126924000548.dkr.ecr.us-east-1.amazonaws.com/liberty/liberty-base:latest \
  sh -c "ls -la /opt/ibm/wlp/ | grep feature"
```


## The feature-cache exists. Now let's see what's actually in it:  
```sh
# List all .esa files in the cache
docker run --rm 126924000548.dkr.ecr.us-east-1.amazonaws.com/liberty/liberty-base:latest \
  ls /opt/ibm/wlp/feature-cache/features/26.0.0.1/ | head -20

# Count how many features we have
docker run --rm 126924000548.dkr.ecr.us-east-1.amazonaws.com/liberty/liberty-base:latest \
  sh -c "ls /opt/ibm/wlp/feature-cache/features/26.0.0.1/*.esa | wc -l"

# Check if jaxrs and mpHealth are there
docker run --rm 126924000548.dkr.ecr.us-east-1.amazonaws.com/liberty/liberty-base:latest \
  sh -c "ls /opt/ibm/wlp/feature-cache/features/26.0.0.1/ | grep -i jaxrs"

docker run --rm 126924000548.dkr.ecr.us-east-1.amazonaws.com/liberty/liberty-base:latest \
  sh -c "ls /opt/ibm/wlp/feature-cache/features/26.0.0.1/ | grep -i mpHealth"
```




## Phase 6: Update Repository by working on file: next-LOCAL-VALIDATION-GUIDE.md 
<!-- 
```bash
git clone https://pixiecloud/was-liberty-base-image.git
cd was-liberty-base-image
```

Edit `Dockerfile` line 2:
```dockerfile
FROM 126924000548.dkr.ecr.us-east-1.amazonaws.com/liberty/liberty-base:latest
``` -->
<!-- 
Edit Dockerfile line 2 → ECR base image
Edit s2i/bin/assemble lines 95, 97, 99 → Add --from=/opt/ibm/wlp/feature-cache

Push and create PR
```

```bash
git add Dockerfile s2i/bin/assemble
git commit -m "Use internal Liberty base image with pre-cached features"
git push origin collins-liberty-cache-fix -->
```

